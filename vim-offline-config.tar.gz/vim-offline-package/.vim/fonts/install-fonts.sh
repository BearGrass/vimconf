#!/bin/bash
# 安装powerline字体
~/.vim/fonts/powerline-fonts/install.sh
echo "Powerline字体安装完成"

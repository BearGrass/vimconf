struct s {
	int i;
};

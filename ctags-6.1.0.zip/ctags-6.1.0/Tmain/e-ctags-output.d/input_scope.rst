===========
title
===========


X	tab	Y
===========
This one will not be recorded.

topic in tab
----------------------
This one will not be recorded if --fileds=+s is given
because a tab char is in the scope field.

X space Y
===========
This one will be recorded.

topic in space
----------------------
This one will be recorded.

struct {
	int x;
} X;

struct {
	int y;
} Y;

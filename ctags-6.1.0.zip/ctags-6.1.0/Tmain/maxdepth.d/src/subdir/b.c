int b(void)
{
  return 0;
}

